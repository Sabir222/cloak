#!/usr/bin/env bash
# install.sh - Non-interactive TroveScout installer (for CI / headless / automation)
# Usage: bash install.sh [--prefix /path/to/agents/skills]
#
# Unlike setup.sh, this script skips interactive prompts and colorful output.
# It is meant for automated environments.

set -euo pipefail

PREFIX="${1:-${HOME}/.agents/skills}"
TROVESCOUT_VERSION="$(cat "$(dirname "$0")/VERSION" 2>/dev/null || echo "3.8.0")"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "[install] TroveScout v${TROVESCOUT_VERSION} — headless install"

# ---- 1. check Python ----
PYTHON=""
for cmd in python3.13 python3.12 python3; do
  if command -v "$cmd" &>/dev/null; then
    ver=$("$cmd" --version 2>&1 | grep -oP '\d+\.\d+')
    major="${ver%.*}"; minor="${ver#*.}"
    if [ "$major" -ge 3 ] && [ "$minor" -ge 12 ]; then
      PYTHON="$cmd"
      break
    fi
  fi
done

if [ -z "$PYTHON" ]; then
  echo "[install] ERROR: Python 3.12+ required" >&2
  exit 1
fi
echo "[install] Python: ${PYTHON}"

# ---- 2. install skill files ----
SKILL_DST="${PREFIX}/trovescout"
mkdir -p "$SKILL_DST"
SKILL_SRC="${SCRIPT_DIR}/skills/trovescout"

if [ -d "$SKILL_SRC" ]; then
  cp -R "$SKILL_SRC/" "$SKILL_DST/"
elif [ -f "${SCRIPT_DIR}/SKILL.md" ]; then
  cp -R "${SCRIPT_DIR}/" "$SKILL_DST/"
else
  echo "[install] ERROR: skill files not found" >&2
  exit 1
fi
echo "[install] Skill → ${SKILL_DST}"

# ---- 3. config ----
CONFIG_DIR="${HOME}/.config/trovescout"
mkdir -p "$CONFIG_DIR"
ENV_FILE="${CONFIG_DIR}/.env"

if [ ! -f "$ENV_FILE" ] && [ -f "${SCRIPT_DIR}/.env.example" ]; then
  cp "${SCRIPT_DIR}/.env.example" "$ENV_FILE"
  chmod 600 "$ENV_FILE"
  echo "[install] Config → ${ENV_FILE}"
fi

# ---- 4. output dir ----
mkdir -p "${HOME}/Documents/TroveScout"

# ---- 5. register with npx ----
if command -v npx &>/dev/null; then
  (cd "$SKILL_DST" && npx skills add . -g -y 2>/dev/null) && \
    echo "[install] Registered with Agent Skills" || \
    echo "[install] Note: npx skills add failed (non-critical)"
fi

echo "[install] TroveScout v${TROVESCOUT_VERSION} installed"
