# TroveScout Quick Start

Get your first research result in 2 minutes.

## Step 1: Install

```bash
unzip trovescout-skill-v3.8.0.zip
cd trovescout-skill-v3.8.0
bash setup.sh
```

## Step 2: Add an API Key

Get a free ScrapeCreators key at https://scrapecreators.com (10,000 free calls).

Edit the config file:

```bash
nano ~/.config/trovescout/.env
```

Add this line:

```
SCRAPECREATORS_API_KEY=your_key_here
```

## Step 3: Run Your First Search

In any AI agent host (Claude Code, Codex, Cursor, etc.):

```
/trovescout AI tools 2026
```

Or directly from the terminal:

```bash
python3 ~/.agents/skills/trovescout/scripts/trovescout.py "AI tools 2026" --emit=compact
```

## Step 4: Try Different Formats

```bash
# Save as a shareable HTML page
/trovescout AI tools 2026 --emit=html

# Focus on specific sources
/trovescout AI tools 2026 --search=reddit,hackernews,github

# Deep research (slower, more thorough)
/trovescout AI tools 2026 --deep

# Quick scan
/trovescout AI tools 2026 --quick
```

## What You'll Get

A synthesized briefing covering:
- What people are saying (top posts, comments, sentiment)
- Emerging patterns and trends
- Key links and sources
- Sentiment distribution across platforms
- Hiring signals (job posts, startup activity)

## Need More?

See **SETUP.md** for full configuration details and all available API keys.
