# TroveScout Setup Guide

## Prerequisites

- **Python 3.12 or later** — check with `python3 --version`
- **Node.js 18 or later** — check with `node --version` (needed for X/Twitter search only)
- An **AI agent host** that supports Agent Skills:
  - Claude Code
  - Codex
  - Cursor
  - Gemini CLI
  - GitHub Copilot
  - Cline / Roo Code
  - Any [Agent Skills](https://agentskills.io) host

## Installation

### Automatic (recommended)

```bash
unzip trovescout-skill-v3.8.0.zip
cd trovescout-skill-v3.8.0
bash setup.sh
```

The script will:
1. Check Python and Node.js versions
2. Copy skill files to `~/.agents/skills/trovescout/`
3. Create `~/.config/trovescout/.env` from the template
4. Create `~/Documents/TroveScout/` for output files
5. Print next steps

### Manual Installation

```bash
# 1. Copy the skill tree
mkdir -p ~/.agents/skills/trovescout
cp -R skills/trovescout/* ~/.agents/skills/trovescout/

# 2. Configure API keys
mkdir -p ~/.config/trovescout
cp .env.example ~/.config/trovescout/.env
chmod 600 ~/.config/trovescout/.env
# Edit the file and add your keys

# 3. Create output directory
mkdir -p ~/Documents/TroveScout

# 4. Register with Agent Skills (optional, for cross-host support)
npx skills add ~/.agents/skills/trovescout -g -y
```

## API Keys

TroveScout works with **zero configuration** for Reddit, Hacker News, Polymarket, and GitHub. For other sources, you need API keys:

### Essential (unlocks most sources)

| Service | What It Unlocks | How to Get |
|---------|----------------|------------|
| **ScrapeCreators** | TikTok, Instagram, Threads, Pinterest, YouTube transcripts | [scrapecreators.com](https://scrapecreators.com) — 10K free calls |

### Optional per source

| Source | Key / Method | How to Get |
|--------|-------------|------------|
| X/Twitter | Browser cookies (`AUTH_TOKEN` + `CT0`) or `XAI_API_KEY` | Free cookies from browser; API key at [console.x.ai](https://console.x.ai) |
| Web search | `BRAVE_API_KEY`, `EXA_API_KEY`, or `SERPER_API_KEY` | Brave has a free tier |
| Bluesky | `BSKY_HANDLE` + `BSKY_APP_PASSWORD` | [bsky.app/settings/app-passwords](https://bsky.app/settings/app-passwords) |
| YouTube | `yt-dlp` on PATH | [github.com/yt-dlp/yt-dlp](https://github.com/yt-dlp/yt-dlp) |
| Transcription | `GROQ_API_KEY` (free) or `OPENAI_API_KEY` | [groq.com](https://groq.com) |

### Configuration Priority

1. Environment variables (highest)
2. `.claude/trovescout.env` (per-project)
3. `~/.config/trovescout/.env` (user-global)
4. macOS Keychain (Darwin only)
5. `pass` store (Linux/Unix)

## Testing Your Installation

```bash
# Direct CLI test (from any directory):
python3 ~/.agents/skills/trovescout/scripts/trovescout.py "AI startups" --emit=compact

# Via AI agent:
/trovescout AI startups
```

## Usage

```
/trovescout <topic>
/trovescout <topic> --emit=html
/trovescout <topic> --search=reddit,hackernews
/trovescout <topic> --deep   (higher recall, slower)
/trovescout <topic> --quick  (faster, less depth)
```

## Output Formats

| Flag | Description |
|------|-------------|
| `--emit=compact` | Terminal-friendly markdown (default) |
| `--emit=html` | Shareable HTML page |
| `--emit=md` | Full markdown with evidence |
| `--emit=json` | Raw structured data |
| `--emit=brief` | One-paragraph summary |

## Getting Help

- Email: hello@trove.dev
- Agent Skills docs: https://agentskills.io
