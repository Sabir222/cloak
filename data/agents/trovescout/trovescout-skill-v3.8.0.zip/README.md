# TroveScout — Multi-Source Research for AI Agents

**TroveScout** is an Agent Skill that researches any topic across 15+ sources — Reddit, X/Twitter, YouTube, TikTok, Instagram, Hacker News, GitHub, Bluesky, Polymarket, Digg, Pinterest, Threads, Truth Social, and the open web — and synthesizes everything into a clear, actionable briefing. All in about 30 seconds.

```
/trovescout nvidia earnings reaction
/trovescout AI video tools 2026
/trovescout what users want in react
```

## Quick Start

```bash
# 1. Unzip the distribution
unzip trovescout-skill-v3.8.0.zip
cd trovescout-skill-v3.8.0

# 2. Run the installer
bash setup.sh

# 3. Add API keys (at minimum a free ScrapeCreators key)
nano ~/.config/trovescout/.env

# 4. Test it
/trovescout AI tools 2026
```

## Requirements

- **Python 3.12+** (stdlib only — no pip packages needed)
- **Node.js 18+** (for X/Twitter search via bird-search)
- An AI agent host: Claude Code, Codex, Cursor, Gemini CLI, or any [Agent Skills](https://agentskills.io) host

## What It Researches

| Source | Auth Required | Status |
|--------|--------------|--------|
| Reddit | None | Always on |
| Hacker News | None | Always on |
| GitHub | `gh` CLI | Auto-detected |
| Polymarket | None | Always on |
| X/Twitter | Cookies or API key | Optional |
| YouTube | `yt-dlp` CLI | Optional |
| TikTok | ScrapeCreators key | Optional |
| Instagram | ScrapeCreators key | Optional |
| Bluesky | App password | Optional |
| Web search | Brave / Exa / Serper key | Optional |
| Digg | `digg-pp-cli` CLI | Optional |
| And more… | | |

## Output Formats

- `compact` — terminal-friendly markdown (default)
- `html` — shareable web page
- `md` — full markdown with all evidence
- `json` — raw structured data
- `brief` — one-paragraph summary

---

**TroveScout** by [Trove](https://trove.dev) · Based on Last30Days (MIT) by Matt Van Horn
