#!/usr/bin/env bash
# setup.sh - Interactive TroveScout installer
# Run this after unzipping the distribution.
# Usage: bash setup.sh

set -euo pipefail

TROVESCOUT_VERSION="$(cat "$(dirname "$0")/VERSION" 2>/dev/null || echo "3.8.0")"

# ---- colors ----
PURPLE='\033[95m'
BLUE='\033[94m'
CYAN='\033[96m'
GREEN='\033[92m'
YELLOW='\033[93m'
RED='\033[91m'
BOLD='\033[1m'
DIM='\033[2m'
RESET='\033[0m'

info()  { printf "${BLUE}::${RESET} %s\n" "$*"; }
ok()    { printf "${GREEN}✓${RESET} %s\n" "$*"; }
warn()  { printf "${YELLOW}⚠${RESET} %s\n" "$*"; }
error() { printf "${RED}✗${RESET} %s\n" "$*"; }
header(){ printf "\n${PURPLE}${BOLD}%s${RESET}\n" "$*"; }

# ---- banner ----
cat <<EOF

${PURPLE}${BOLD}
   ████████╗██████╗  ██████╗ ██╗   ██╗███████╗
   ╚══██╔══╝██╔══██╗██╔═══██╗██║   ██║██╔════╝
      ██║   ██████╔╝██║   ██║██║   ██║█████╗
      ██║   ██╔══██╗██║   ██║╚██╗ ██╔╝██╔══╝
      ██║   ██║  ██║╚██████╔╝ ╚████╔╝ ███████╗
      ╚═╝   ╚═╝  ╚═╝ ╚═════╝   ╚═══╝  ╚══════╝
${RESET}
${DIM}  Multi-source research for AI agents  v${TROVESCOUT_VERSION}${RESET}

EOF

echo "This script will install TroveScout and check prerequisites."
echo ""

# ---- 1. check Python ----
header "1. Checking Python"
PYTHON=""
for cmd in python3.13 python3.12 python3; do
  if command -v "$cmd" &>/dev/null; then
    ver=$("$cmd" --version 2>&1 | grep -oP '\d+\.\d+')
    major="${ver%.*}"
    minor="${ver#*.}"
    if [ "$major" -ge 3 ] && [ "$minor" -ge 12 ]; then
      PYTHON="$cmd"
      ok "Python ${ver}+ found: ${PYTHON}"
      break
    fi
  fi
done

if [ -z "$PYTHON" ]; then
  error "Python 3.12+ is required but not found."
  error "Install it: https://www.python.org/downloads/"
  echo "  Or on Ubuntu: sudo apt install python3.12"
  echo "  Or on macOS:  brew install python@3.12"
  exit 1
fi

# ---- 2. check Node.js ----
header "2. Checking Node.js"
if command -v node &>/dev/null; then
  node_ver=$(node --version 2>&1 | sed 's/^v//')
  node_major="${node_ver%%.*}"
  if [ "$node_major" -ge 18 ]; then
    ok "Node.js v${node_ver} found"
  else
    warn "Node.js v${node_ver} found (v18+ recommended for X/Twitter search)"
  fi
else
  warn "Node.js not found. X/Twitter search via bird-search won't work."
  warn "Install: https://nodejs.org/ (v18 or later)"
fi

# ---- 3. install skill files ----
header "3. Installing skill files"

SKILL_DST="${HOME}/.agents/skills/trovescout"
mkdir -p "$SKILL_DST"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_SRC="${SCRIPT_DIR}/skills/trovescout"

if [ -d "$SKILL_SRC" ]; then
  cp -R "$SKILL_SRC/" "$SKILL_DST/"
  ok "Skill installed to ${SKILL_DST}"
  info "Slash command: ${CYAN}/trovescout <topic>${RESET}"
else
  # If running from inside the unzipped tree directly
  if [ -d "${SCRIPT_DIR}/SKILL.md" ] || [ -f "${SCRIPT_DIR}/SKILL.md" ]; then
    cp -R "${SCRIPT_DIR}/" "$SKILL_DST/"
    ok "Skill installed to ${SKILL_DST}"
  else
    error "Could not find skill files at ${SKILL_SRC}"
    error "Make sure you unzipped the full distribution package."
    exit 1
  fi
fi

# Also register via npx if available
if command -v npx &>/dev/null; then
  info "Registering skill via Agent Skills..."
  (cd "$SKILL_DST" && npx skills add . -g -y 2>/dev/null) && \
    ok "Skill registered with Agent Skills" || \
    warn "Could not register via npx skills add (not critical — skill files are in place)"
fi

# ---- 4. create config directory ----
header "4. Setting up configuration"

CONFIG_DIR="${HOME}/.config/trovescout"
mkdir -p "$CONFIG_DIR"

ENV_FILE="${CONFIG_DIR}/.env"

if [ -f "$ENV_FILE" ]; then
  warn ".env already exists at ${ENV_FILE} (not overwritten)"
else
  if [ -f "${SCRIPT_DIR}/.env.example" ]; then
    cp "${SCRIPT_DIR}/.env.example" "$ENV_FILE"
    chmod 600 "$ENV_FILE"
    ok "Created ${ENV_FILE}"
    info "Edit it to add your API keys: ${CYAN}nano ${ENV_FILE}${RESET}"
  else
    warn "No .env.example found — create ${ENV_FILE} manually"
  fi
fi

# Check permissions
if [ -f "$ENV_FILE" ]; then
  chmod 600 "$ENV_FILE" 2>/dev/null || true
fi

# ---- 5. output memory dir ----
MEMORY_DIR="${HOME}/Documents/TroveScout"
mkdir -p "$MEMORY_DIR"
ok "Output directory: ${MEMORY_DIR}"

# ---- 6. summary ----
header "Setup complete!"

cat <<EOF

${BOLD}What's next:${RESET}

1. ${CYAN}Add API keys${RESET} — edit ${CONFIG_DIR}/.env
   At minimum, get a ${BOLD}ScrapeCreators${RESET} key (free tier: 10k calls):
   → https://scrapecreators.com

2. ${CYAN}Test it${RESET}:
   ${DIM}# Direct CLI:${RESET}
   python3 "${SKILL_DST}/scripts/trovescout.py" "AI tools 2026" --emit=compact

   ${DIM}# Via AI agent (Claude Code, Codex, etc.):${RESET}
   /trovescout AI tools 2026

3. ${CYAN}Quick start guide${RESET}: see QUICKSTART.md in this directory.

${DIM}Need help? hello@trove.dev${RESET}
EOF
